#!/bin/bash
bash src/scripts/scriptCSV_lpthread.sh $1
bash src/scripts/scriptCSV_ts.sh $1
bash src/scripts/scriptCSV_tts.sh $1
bash src/scripts/scriptCSV_btts.sh $1